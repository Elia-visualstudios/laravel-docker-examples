const API_BASE = 'http://127.0.0.1:8000/api';
async function apiRequest(url, method = 'GET', data = null, headers = {}) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
            ...headers
        }
    };

    if (method !== 'GET' && data) {
        options.body = JSON.stringify(data);
    }

    if (method === 'GET' && data) {
        const params = new URLSearchParams(data).toString();
        url += '?' + params;
    }

    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            const errorText = await response.text(); // Leggi il corpo della risposta per più dettagli
            throw new Error(`Errore HTTP ${response.status}: ${errorText}`);
        }
        // Alcune richieste (es. DELETE) potrebbero non restituire JSON
        if (response.headers.get('content-type')?.includes('application/json')) {
            return await response.json();
        }
        return response.status; // Ritorna lo status per richieste senza JSON (es. 200 OK)
    } catch (error) {
        console.error('Errore nella richiesta API:', error);
        throw error;
    }
}

const notaForm = document.querySelector('#nota-form');
const notaInput = document.querySelector('#insert-nota');
const bottoneLista = document.querySelector('#note-list');
const divLista = document.querySelector('#note-list-div');
const listaSelect = document.querySelector('#lista-select');
const listaForm = document.querySelector('#lista-form');
const listaInput = document.querySelector('#insert-lista');
let listaAttivaId = null;

// --- Aggiungi Nota ---
notaForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const nota = notaInput.value.trim();

    if (nota === '' || !listaAttivaId) {
        alert('Inserisci una nota valida!');
        return;
    }

    apiRequest(`${API_BASE}/listas/${listaAttivaId}/notes`, 'POST', { text: nota, checkbox: false })
        .then(data => {
            console.log('Nota aggiunta:', data);
            notaInput.value = '';
            aggiornaLista(); // Ricarica la lista dopo l'aggiunta
        })
        .catch(error => console.error('Errore durante l\'aggiunta della nota:', error));
});

// --- Funzione per caricare e mostrare la lista delle note ---
function aggiornaLista() {
    if (!listaAttivaId) return;
    apiRequest(`${API_BASE}/listas/${listaAttivaId}/notes`)
        .then(data => {
            divLista.innerHTML = ''; // Pulisce il contenitore prima di riempirlo

            data.forEach(nota => {
                const item = document.createElement('div');
                item.className = 'note-item';

                // Checkbox
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.checked = nota.checkbox; 
                checkbox.id = `checkbox-${nota.id}`; 

                // Listener per la checkbox
                checkbox.addEventListener('change', () => {
                    const newCheckboxState = checkbox.checked;
                    apiRequest(`${API_BASE}/notes/update/${nota.id}`, 'PUT', { checkbox: newCheckboxState })
                        .then(() => {
                            if (newCheckboxState) {
                                textSpan.classList.add('sbarrato');
                            } else {
                                textSpan.classList.remove('sbarrato');
                            }
                        })
                        .catch(error => console.error(`Errore nell'aggiornamento della nota ${nota.id}:`, error));
                });

                // Testo della nota
                const textSpan = document.createElement('span');
                textSpan.textContent = nota.text;
                if (nota.checkbox) {
                    textSpan.classList.add('sbarrato');
                }

                // Bottone Modifica
                const editButton = document.createElement('button');
                editButton.textContent = 'Modifica';
                editButton.className = 'edit-button';
                editButton.addEventListener('click', () => {
                    const nuovoTesto = prompt('Modifica la nota:', nota.text);
                    if (nuovoTesto !== null && nuovoTesto.trim() !== '') {
                        apiRequest(`${API_BASE}/notes/edit/${nota.id}`, 'PUT', { text: nuovoTesto.trim() })
                            .then(() => {
                                aggiornaLista();
                            })
                            .catch(error => console.error(`Errore nella modifica della nota ${nota.id}:`, error));
                    }
                });

                // Bottone Elimina
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'X';
                deleteButton.className = 'delete-button'; // Aggiungi una classe per styling
                deleteButton.addEventListener('click', () => {
                    if (confirm('Sei sicuro di voler eliminare questa nota?')) {
                        apiRequest(`${API_BASE}/notes/del/${nota.id}`, 'DELETE')
                            .then(() => {
                                console.log(`Nota ${nota.id} eliminata.`);
                                aggiornaLista(); // Ricarica la lista dopo l'eliminazione
                            })
                            .catch(error => console.error(`Errore durante l'eliminazione della nota ${nota.id}:`, error));
                    }          
                });

                item.appendChild(checkbox);
                item.appendChild(textSpan);
                item.appendChild(editButton); // Aggiungi il bottone modifica
                item.appendChild(deleteButton);
                divLista.appendChild(item);
            });
        })
        .catch(error => console.error('Errore nel caricamento della lista:', error));
}

// Quando clicchi sul pulsante "Lista di note"
bottoneLista.addEventListener('click', () => {
    console.log('Caricamento note...');
    aggiornaLista();
});

// Carica tutte le liste e popola la select
function aggiornaListe() {
    apiRequest(`${API_BASE}/listas`)
        .then(lists => {
            listaSelect.innerHTML = '';
            lists.forEach(list => {
                const option = document.createElement('option');
                option.value = list.id;
                option.textContent = list.nome;
                listaSelect.appendChild(option);
            });
            if (lists.length > 0) {
                listaAttivaId = lists[0].id;
                aggiornaLista();
            }
        });
}

// Quando cambio lista
listaSelect.addEventListener('change', () => {
    listaAttivaId = listaSelect.value;
    aggiornaLista();
});

// Aggiungi nuova lista
listaForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const nome = listaInput.value.trim();
    if (nome === '') return;
    apiRequest(`${API_BASE}/listas`, 'POST', { nome })
        .then(() => {
            listaInput.value = '';
            aggiornaListe();
        });
});

// Carica la lista delle note all'avvio della pagina
document.addEventListener('DOMContentLoaded', () => {
    aggiornaListe();
    aggiornaLista();
});

console.log('Frontend aggiornato con checkbox e eliminazione!');